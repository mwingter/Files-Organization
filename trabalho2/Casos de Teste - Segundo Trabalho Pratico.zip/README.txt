Arquivo zip gerado em: 15/05/2019 19:00:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Segundo Trabalho Prático