#ifndef H_ESCREVERNATELA_
	
	#define H_ESCREVERNATELA_

	void leCsv_SalvaBin();
	void leBin_PrintBin();
	void buscaBin_Print();
	void remove_registro();
	void insere_registro();
	void atualiza_registro();
	void ordenacao_interna();
	void merge_twoFiles();
	void match_twoFiles();

#endif
